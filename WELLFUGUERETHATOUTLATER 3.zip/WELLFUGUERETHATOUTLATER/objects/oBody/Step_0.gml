if(instance_exists(obj_dialog)) exit;

if(instance_exists(oPlayer) && distance_to_object(oPlayer) < 10){
	can_talk= true;
	if (keyboard_check_pressed(vk_space)){

		show_message("Who killed the council man?")
		show_message("Q. The Queen W. The Worker G. The Guard")
	}
	if (keyboard_check_pressed(ord("Q"))){
			show_message("You found the murderer!")
		}else if (keyboard_check_pressed(ord("W"))){
			show_message("You're wrong.")
			game_end()
		}else if(keyboard_check_pressed(ord("G"))){
			show_message("You're wrong.")
			game_end()
		}
}else{
	can_talk = false
}