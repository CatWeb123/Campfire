x_speed = 0; 

y_speed = 0; 

movement_speed = 5; 

grav = 0.5;