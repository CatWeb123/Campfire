
x_speed = 0;
y_speed += grav;
sprite_index = sPlayer

//if (instance_exists(obj_dialog)) exit;


if keyboard_check(vk_right) {

    x_speed = movement_speed;
	image_xscale = 1
	sprite_index = sPlayerR
} else if keyboard_check(vk_left) {

    x_speed = -movement_speed;
	image_xscale = -1
	sprite_index = sPlayerR
}
move_and_collide(x_speed, y_speed, oSolid);


if(place_meeting(x, y + 1, oSolid)) {
	if (keyboard_check(vk_up)){
		y_speed = -12;
		if (keyboard_check(vk_right)){
			x_speed = 20;
			image_xscale = 1
			sprite_index = sPlayerR
			
		}else if(keyboard_check(vk_left)){
			x_speed = -20;
			image_xscale = -1
			sprite_index = sPlayerR
		}
	}else {
      y_speed = 0;
	}
}
if (place_meeting(x, y, oNext))
{
    room_goto_next();
	
}
if (place_meeting(x, y, oPrevious))
{
    room_goto_previous();
}