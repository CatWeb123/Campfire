if(instance_exists(obj_dialog)) exit;

if(instance_exists(oPlayer) && distance_to_object(oPlayer) < 30){
	can_talk= true;
	if (keyboard_check_pressed(vk_space)){
		 create_dialog(dialog);
	}
}else{
	can_talk = false
}