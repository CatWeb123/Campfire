draw_self();

if (can_talk && !instance_exists(obj_dialog)){
	draw_sprite( Sprite17, 0, x, y -16)
}
