function create_dialog(_messages){
	if (instance_exists(obj_dialog)) return;
	
	var _inst = instance_create_depth(0, 0, 0, obj_dialog);
	_inst.messages = _messages;
	_inst.current_message = 0;
	
}
char_colors = {
	"Queen": c_yellow,
	"Kafka": c_blue,
	"Worker": c_lime,
	"Guard1": c_red,
	"Guard2": c_red,
	
}


Queen_dialog = [
{
	name: "Queen",
	msg: "A terrible scenerio has befalen this kingdom, our Ruler, The Gret One, has been murdered. I fear that one of my subjects might have been the purpetrator, so, I need your help Marine biologist, to catch and punish whoever did this.",
},
{
	name: "Marine biologist",
	msg: "You can call me Kafka, so, any ideas who it might be?",
},
{
	name: "Queen",
	msg: "The people of this place have long since been uneasy, most do not get along. The knights, still as loyal to The Great One as always, never to anyone else...they seem to despise the peasn-, I mean, the workers. The workers do not favor me, but they tend to keep their head down, even if a bit gossipy.",
},
{
	name: "Kafka",
	msg: "Right...thank you, i' ll look into it, i'm sure we can find the guilty person and bring justice to The Great One.",
},
{
	name: "Queen",
	msg: "Ofcource, that is...all I could ask for.",
},
]

Worker_dialog =[
{
	name: "Worker",
	msg: "Psst,hey!",
},
{
	name: "Worker",
	msg: "What do you think about the queen?",
},

{
	name: "Worker",
	msg: "..I am not here to judge, but just expressing my opinion.",
},

{
	name: "Kafka",
	msg: "Uhh..who exatcly are you?",
},
{
	name: "Worker",
	msg: "I am the worker bee!",
},
{
	name: "Worker bee",
	msg: "And I do not enjoy this queen's presence, she gives me eerie vibes..",
},
{
	name: "Kafka",
	msg: "I mean, I haven't met her yet, so I can't tell..",
},
{
	name: "Worker bee",
	msg: "Well whatever you do, be careful, she is mean and all that blahblah..", 
},
{
	name: "Worker bee",
	msg: "I hope she leaves one day.",
},
{
	name: "Kafka",
	msg: "Uh, you have a nice day aswell..I guess..",
},
{
	name: "Worker bee",
	msg: "BTW! The knights or guards or whatever they are, they have become very very quiet..",
},
]


Guard_dialog =[
{
	name: "Guard",
	msg: "Halt! Who goes there?",
},
{
	name: "Guard",
	msg: "Oh, It's you, doctor.",
},
{
	name: "Guard",
	msg: "I thought its was a peasant, they are allways cousing trouble!",
},
	{
	name: "Kafka",
	msg: "Do you know who could've killed the council man.",
},
{
	name: "Guard",
	msg: "It's probably the Queen, she has been fighting for complete power with the council for a long time.",
},
{
	name: "Kafka",
	msg: "Oh, thanks",
},

]